package lab04.src.lab04;

public class Lab04 {
    public static void main(String[] args) {

    }
}
