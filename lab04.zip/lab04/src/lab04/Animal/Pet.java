package lab04.src.lab04.Animal;

public interface Pet {
    String getName();

    void setName(String name);

    void play();
}
