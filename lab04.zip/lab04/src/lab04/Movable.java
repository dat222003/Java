package lab04.src.lab04;

public interface Movable {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();
}
