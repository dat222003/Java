package lab04.src.lab04;

public class Rectangle extends Shape {

    private int length;
    private int width;

    Rectangle(){
        super();
    }

    Rectangle(String color, int length, int width) {
        super(color);
        this.length = length;
        this.width = width;
    }

    @Override
    public double getArea() {
        return this.length * this.width;
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "length=" + length +
                ", width=" + width +
                '}';
    }
}
